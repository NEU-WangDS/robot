/*
 * @文件描述:
 * @作者: Q
 * @Date: 2023-02-13 16:09:51
 * @LastEditTime: 2023-03-23 10:39:35
 */
#ifndef _APP_SENSOR_H_
#define _APP_SENSOR_H_
#include "main.h"

void app_sensor_init(void);
void app_sensor_run(void);


#endif
