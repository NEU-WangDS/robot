/*
 * @文件描述: 
 * @作者: Q
 * @Date: 2023-02-13 16:09:51
 * @LastEditTime: 2023-02-23 09:48:13
 */
#ifndef _APP_UART_H_
#define _APP_UART_H_
#include "main.h"


void app_uart_init(void);
void app_uart_run(void);


#endif
