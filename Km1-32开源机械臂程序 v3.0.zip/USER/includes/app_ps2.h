/*
 * @文件描述: 
 * @作者: Q
 * @Date: 2023-02-13 16:09:51
 * @LastEditTime: 2023-02-15 17:39:43
 */
#ifndef _APP_PS2_H_
#define _APP_PS2_H_
#include "main.h"


void app_ps2_init(void);
void app_ps2_run(void);
#endif
